/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pl1.pdl;

import java.io.IOException;

/**
 *
 * @author Alberto
 */
public class Main {
    
    public static void main(String[] args) throws IOException {
        Integer estados = 4; //Cambiar
        Integer inicial = 0; //Cambiar
        Integer finales[] = {2,4}; //Cambiar
        
        String cadena[] = {"aaaaaaa","abc","","aaa","aaaab","abccccc"}; //Cambiar
        
        int cuantasCadenas = 100; //Cambiar
        int longitudCadena = 10; //Cambiar
        int iteraciones = 1000; //Cambiar
        
        
        AutomataFinitoD automata = new AutomataFinitoD();
        automata.cargarAlfabeto();
        automata.cargarEstados(estados);
        automata.establecerQi(inicial);
        automata.establecerQf(finales);
        automata.inicializarMatriz(estados);
        automata.cargarMatriz();
        automata.imprimir();
        
        MaquinaEstados maquina = new MaquinaEstados(automata);
        automata.escribir("COMPROBACION CADENAS");
        for(String cadena1 : cadena){
            System.out.println("Cadena ("+cadena1+")" + " -> " + maquina.comprobarCadena(cadena1));
            automata.escribir("Cadena ("+cadena1+")" + " -> " + maquina.comprobarCadena(cadena1));
        }
        automata.escribir("  ");
        maquina.generarListaCadenas(iteraciones, longitudCadena);
        maquina.imprimirCadenas(cuantasCadenas);
        
        automata.getFw().close();
    }
    
}
