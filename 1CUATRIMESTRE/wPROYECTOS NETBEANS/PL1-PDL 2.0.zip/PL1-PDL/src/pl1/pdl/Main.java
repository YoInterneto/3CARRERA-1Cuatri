/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pl1.pdl;

/**
 *
 * @author Alberto
 */
public class Main {
    
    public static void main(String[] args) {
        Integer estados = 4; //Cambiar
        Integer inicial = 0; //Cambiar
        Integer finales[] = {1,3,4}; //Cambiar
        String cadena = "a"; //Cambiar
        String cadena1 = "abcd"; //Cambiar
        String cadena2 = "abc"; //Cambiar
        int cuantasCadenas = 100; //Cambiar
        int longitudCadena = 10; //Cambiar
        int iteraciones = 1000; //Cambiar
        
        AutomataFinitoD automata = new AutomataFinitoD();
        automata.cargarAlfabeto();
        automata.cargarEstados(estados);
        automata.establecerQi(inicial);
        automata.establecerQf(finales);
        automata.inicializarMatriz(estados);
        automata.cargarMatriz('a',estados);
        automata.cargarMatriz('b',estados);
        automata.cargarMatriz('c',estados);
        automata.cargarMatriz('d',estados);
        //System.out.println("MATRIZ");
        //automata.imprimir();
        //automata.cargarMatriz('e',estados);
        
        MaquinaEstados maquina = new MaquinaEstados(automata);
        System.out.println(cadena+" -> "+maquina.comprobarCadena(cadena));
        System.out.println(cadena1+" -> "+maquina.comprobarCadena(cadena1));
        System.out.println(cadena2+" -> "+maquina.comprobarCadena(cadena2));
        
        maquina.generarListaCadenas(iteraciones, longitudCadena);
        maquina.imprimirCadenas(cuantasCadenas);
    }
    
}
