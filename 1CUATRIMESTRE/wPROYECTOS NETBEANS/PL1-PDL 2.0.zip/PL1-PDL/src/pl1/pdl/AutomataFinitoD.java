/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pl1.pdl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

/**
 *
 * @author Alberto
 */
public class AutomataFinitoD {
    
    private ArrayList<Character> alfabeto;
    private ArrayList<Integer> estados;
    private ArrayList<Integer> estadosF;
    
    private HashMap<Integer,HashMap<Character,Integer>> matrizEstados;
    
    private Integer estadoI;
    
    private Scanner scanner;

    public AutomataFinitoD(){
        
        alfabeto = new ArrayList<>();
        estados = new ArrayList<>();
        estadosF = new ArrayList<>();
        
        matrizEstados = new HashMap<>();
        
        scanner = new Scanner(System.in);
    }
    
    public void cargarAlfabeto() {
        for(int i = 0; i < 26; i++){
            alfabeto.add((Character)(char)((int)'a' + i));
        }
        
        for(int i = 0; i < 10; i++){
            alfabeto.add((Character)(char)((int)'0' + i));
        }
        
        alfabeto.add((Character)(char)((int)32));
        
        System.out.println("ALFABETO -> "+alfabeto.toString());

    }
    
    public void cargarEstados(Integer numero) {
        for(int i = 0; i <= numero; i++){
            estados.add(i);
        }
        System.out.println("ESTADOS -> "+estados.toString());
    }
    
    public void establecerQf(Integer finales[]) {
        for(int i = 0; i < finales.length; i++){
            estadosF.add(finales[i]);
        }
        System.out.println("FINALES -> "+estadosF.toString());
    }
    
    public void establecerQi(Integer inicial) {
        estadoI = inicial;
        System.out.println("INCIAL -> "+estadoI);
    }
    
    public void inicializarMatriz(Integer numEstados) {
        for(int i=0;i<=numEstados;i++){
            matrizEstados.put(i, new HashMap<>());
        }
    }
    
    public void cargarMatriz(Character caracter, Integer numero){
        for(int i=0; i<=numero; i++){
            System.out.println("Introduzca  "+caracter + " x "+i);
            Integer estadoMatriz = scanner.nextInt();
            
            matrizEstados.get(i).put(caracter, estadoMatriz);
        }
    }
    
    public Integer siguienteEstado(Integer estado, Character caracter) {
        return matrizEstados.get(estado).get(caracter);
    }
    
    public Boolean esFinal(Integer estado) {
        return estadosF.contains(estado);
    }
    
    public void imprimir(){
        for(int i=0; i<estados.size(); i++){
            System.out.println(matrizEstados.get(i).toString());
        }
    }
    
    
    //TODOS LOS METODOS GETTERS NECESARIOS PARA LA CORRECTA EJECUCIÓN DEL 
    //PROGRAMA
    public ArrayList<Character> getAlfabeto() {
        return alfabeto;
    }

    public ArrayList<Integer> getEstados() {
        return estados;
    }

    public HashMap<Integer, HashMap<Character, Integer>> getMatrizEstados() {
        return matrizEstados;
    }

    public Integer getEstadoInicial() {
        return estadoI;
    }
}
