/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pl1.pdl;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author Alberto
 */
public class MaquinaEstados {
    
    AutomataFinitoD automata = new AutomataFinitoD();
    Integer estadoInicial;
    HashMap <Integer, HashMap<Character, Integer>> matrizEstados = new HashMap<>();
    ArrayList <String> cadenas = new ArrayList<>();
    
    public MaquinaEstados(AutomataFinitoD a){
        this.automata = a;
        this.estadoInicial = automata.getEstadoInicial();
        this.matrizEstados = automata.getMatrizEstados();
    }
    
    public void aceptar(Character caracter) throws Exception{
        
        Integer estadoTmp = automata.siguienteEstado(estadoInicial, caracter);
        
        if(estadoTmp!=-1){
            estadoInicial = estadoTmp;
        }else{
            throw new Exception();
        }
    }
    
    public boolean esFinal(){
        return automata.esFinal(estadoInicial);
    }
    
    public boolean comprobarCadena(String cadena){
        
        try{
            this.estadoInicial = automata.getEstadoInicial();
            for(int i=0; i<cadena.length(); i++){
                this.aceptar((Character)cadena.charAt(i));
                if((esFinal())&&(i==cadena.length()-1)){
                    return true;
                }
            }
        }catch(Exception e){
            System.out.println(e);
        }
        
        return false;
    }
}
